

### Issues:

A new User logs in:
- After logging in you receive a blank page and were asked to login in again

Login Page:
- Auth Token does not refresh
- The old styles no longer show

Profile Page:
- Add info in local storage the first time and then periodically check if its changed.

Favorite Page:
- Playlists should expand when clicked
- Fix Icon for expand

AudioPage:
- remove keybinding for refresh and dev console
- Properly Manage Audio Store data with actions
- 
PlayerPage: 
  Queue View:
    1.) in order animate transition, toggle gooey effect and grow bar to properly fit top bar
    2.) in the div below generate the queue results.
    3.) remove and play functionality on list item click
    4.) properly animate transition down and then restart gooeyness
    5.) be sure that everything is properly toggled
