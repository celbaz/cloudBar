Add to your application folder and then double click it!
